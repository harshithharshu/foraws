package cow_bull_app.Multiplayer;

import org.springframework.data.repository.CrudRepository;

public interface MultiplayerGameRepository extends CrudRepository<Game, String>{
}
